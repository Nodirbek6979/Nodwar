<?php

$config = [
    'TOKEN'=>"5122488255:AAFTWdB_E4-NtShPkcQBI2axi10C35n1dLw",
    'ADMINNAME'=>"",
    "DataBase"=>[
        'host'=>'hostname',
        'user'=>'username',
        'password'=>'password',
        'dbname'=>'databasename',
    ],
];
