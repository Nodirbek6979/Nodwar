<?php
require "vendor/autoload.php";

require "config.php";
//
use App\CoderLast\Framework;
use App\CoderLast\Plugins;
//
$bot = new Framework($config['TOKEN']);
$plugins = new Plugins($config['TOKEN']);
$database = new sqlite("database/database.db");
$home = [
	["📥 Hisob to'ldirish", "📤 Pul chiqarish"],
	["📈 Kurs", "💻 Aloqa"],
];


$home_2 = [
	["☎️ Raqamni yuborish"],
	["🔙 Bosh menu"],
];

$input = $bot->getInput();
if(isset($input->message)){
	$message = $input->message;
	$chat_id = $message->chat->id;
	$text = $message->text;
	$userid	= $message->from->id;
	$name = $message->from->frist_name." ".$message->from->last_name;


	$contact = $message->contact->phone_number;	
}

$log = $plugins->getSession($chat_id);


if ($text == "/start") {
	$getUser = $database->onerow("SELECT * FROM users WHERE user_id=$chat_id");
	if ($getUser) {
		$bot->sendMessage($chat_id, "Salom bu mening birinchi botim",[
			'reply_markup'=>$plugins->Keyboards($home)
		]);
	}else{
		$database->query("INSERT INTO users('user_id','name') VALUES($chat_id, '$name')");
		$plugins->setSession("reg", $chat_id);
		$bot->sendMessage($chat_id, "Telefon raqamingizni yuboring",[
			'reply_markup'=>json_encode([
				'resize_keyboard'=>true,
				'keyboard'=>[
					[['text'=>"Telefon raqam yuborish", 'request_contact'=>true]]
				]
			])
		]);
	}	
}

if ($log == "reg") {
	$bot->sendMessage($chat_id, 'Siz regdasiz');
}


if ($text == "📥 Hisob to'ldirish") {
    $bot->sendMessage($chat_id, "Salom bu mening birinchi botim",[
		'reply_markup'=>$plugins->Keyboards($home_2)
	]);
}
if ($text == "🔙 Bosh menu") {
    $bot->sendMessage($chat_id, "Salom bu mening birinchi botim",[
		'reply_markup'=>$plugins->Keyboards($home)
	]);
}
if ($text == "📈 Kurs") {
	$bot->sendMessage($chat_id, "Bizda pul tushurish va yechish mutlaqo *0* %",[
		'parse_mode'=>"markdown"
	]);
    
}
if ($text == "💻 Aloqa") {
	$bot->sendMessage($chat_id, "💸 Kimni puli tushmagan bo'lsa javobgarlar:
	Администратор @peyxbot",);
    
}

if ($text == "/users") {
	$getUsers = count($database->row("SELECT * FROM users"));

	$bot->sendMessage($chat_id, "F : $getUsers");
}